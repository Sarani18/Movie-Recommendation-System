import pickle
# new_df = pickle.load(open('new.pkl','rb'))
# movies = pickle.load(open('movie_dict.pkl','rb'))
# similarity = pickle.load(open('similarity.pkl','rb'))